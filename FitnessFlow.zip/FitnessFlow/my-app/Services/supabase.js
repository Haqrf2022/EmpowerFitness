import { createClient } from "@supabase/supabase-js";

// Get Supabase credentials from environment variables
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

// Safety check
if (!supabaseUrl || !supabaseKey) {
  throw new Error("Missing SUPABASE_URL or SUPABASE_KEY in environment.");
}

// ✅ Initialize Supabase client correctly
export const supabase = createClient(supabaseUrl, supabaseKey);

/**
 * Upload file to Supabase storage
 */
export const uploadFile = async (bucket, path, file, options = {}) => {
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(path, file, {
        cacheControl: "3600",
        upsert: false,
        ...options,
      });

    if (error) {
      throw error;
    }

    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(path);

    return {
      path: data.path,
      fullPath: `${bucket}/${data.path}`,
      url: urlData.publicUrl,
    };
  } catch (error) {
    console.error("Supabase storage upload error:", error);
    throw error;
  }
};

/**
 * Get or create user profile
 */
export const getOrCreateProfile = async (userId, userData) => {
  try {
    const { data: existingProfile } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();

    if (existingProfile) {
      return existingProfile;
    }

    const newProfile = {
      id: userId,
      full_name: userData.name || "",
      email: userData.email || "",
      avatar_url: userData.picture || "",
      updated_at: new Date().toISOString(),
    };

    const { data: createdProfile, error: createError } = await supabase
      .from("profiles")
      .insert([newProfile])
      .select();

    if (createError) {
      throw createError;
    }

    return createdProfile[0];
  } catch (error) {
    console.error("Supabase profile operation error:", error);
    throw error;
  }
};
