import { useLocalSearchParams } from "expo-router";
import { View, Text, StyleSheet } from "react-native";

const WorkoutDetail = () => {
  const { title, duration, calories, steps } = useLocalSearchParams();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.detail}>Duration: {duration} mins</Text>
      <Text style={styles.detail}>Calories: {calories}</Text>
      <Text style={styles.detail}>Steps: {steps}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: "#fff",
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 12,
  },
  detail: {
    fontSize: 18,
    marginVertical: 4,
  },
});

export default WorkoutDetail;
