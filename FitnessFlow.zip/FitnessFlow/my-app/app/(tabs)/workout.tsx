import { StyleSheet, ScrollView } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import WorkoutCard from "@/components/WorkoutCard"; // ✅ Make sure this import path is correct

export default function WorkoutScreen() {
  return (
    <ThemedView style={styles.container}>
      <ThemedText type="title">Workout Plans</ThemedText>
      <ThemedText>Select a workout to get started.</ThemedText>

      <ScrollView contentContainerStyle={styles.cardContainer}>
        <WorkoutCard
          title="Full Body Blast"
          duration="45 mins"
          calories="500"
          steps="5000"
        />
        <WorkoutCard
          title="Cardio Burn"
          duration="30 mins"
          calories="300"
          steps="3500"
        />
        <WorkoutCard
          title="Core Strength"
          duration="40 mins"
          calories="400"
          steps="4000"
        />
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    gap: 8,
  },
  cardContainer: {
    marginTop: 16,
  },
});
