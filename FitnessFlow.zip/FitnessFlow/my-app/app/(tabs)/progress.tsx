import { View, Text, StyleSheet } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";

export default function ProgressScreen() {
  return (
    <ThemedView style={styles.container}>
      <ThemedText type="title">Your Progress</ThemedText>
      <ThemedText>Track your fitness journey here.</ThemedText>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    gap: 8,
  },
});
