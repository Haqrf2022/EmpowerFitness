// app/tabs/WorkoutLogger.tsx
import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet, Alert } from "react-native";
import { supabase } from "../../Services/supabase";

// ✅ Corrected path to AuthContext
import { useAuth } from "../../../context/AuthContext";

const WorkoutLogger = () => {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [duration, setDuration] = useState("");
  const [calories, setCalories] = useState("");
  const [steps, setSteps] = useState("");

  const handleSubmit = async () => {
    if (!title || !duration || !calories || !steps) {
      return Alert.alert("Validation Error", "All fields are required.");
    }

    const { error } = await supabase.from("content").insert([
      {
        user_id: user?.id, // Added optional chaining to avoid crash if user is null
        title,
        duration: parseInt(duration),
        calories: parseInt(calories),
        steps: parseInt(steps),
        content: "Custom workout log",
      },
    ]);

    if (error) {
      console.error(error);
      return Alert.alert("Error", "Failed to log workout.");
    }

    Alert.alert("Success", "Workout logged successfully!");
    setTitle("");
    setDuration("");
    setCalories("");
    setSteps("");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Log Your Workout</Text>
      <TextInput
        placeholder="Title"
        value={title}
        onChangeText={setTitle}
        style={styles.input}
      />
      <TextInput
        placeholder="Duration (mins)"
        value={duration}
        onChangeText={setDuration}
        keyboardType="numeric"
        style={styles.input}
      />
      <TextInput
        placeholder="Calories"
        value={calories}
        onChangeText={setCalories}
        keyboardType="numeric"
        style={styles.input}
      />
      <TextInput
        placeholder="Steps"
        value={steps}
        onChangeText={setSteps}
        keyboardType="numeric"
        style={styles.input}
      />
      <Button title="Log Workout" onPress={handleSubmit} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20, flex: 1 },
  heading: { fontSize: 20, fontWeight: "bold", marginBottom: 20 },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    marginBottom: 15,
    padding: 10,
    borderRadius: 8,
  },
});

export default WorkoutLogger;
