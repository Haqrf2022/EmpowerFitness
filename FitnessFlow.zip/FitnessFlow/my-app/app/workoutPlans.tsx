import { useRouter } from "expo-router";
import { View, Button, TouchableOpacity } from "react-native";
import WorkoutCard from "../components/WorkoutCard"; // You had this as ../components/ before

const WorkoutPlans = ({ workout }) => {
  const router = useRouter();

  return (
    <View>
      {/* ✅ Add navigation button to WorkoutLogger */}
      <Button
        title="Log a Custom Workout"
        onPress={() => router.push("/WorkoutLogger")}
      />

      <TouchableOpacity
        onPress={() =>
          router.push({
            pathname: "/WorkoutDetail",
            params: {
              title: workout.title,
              duration: workout.duration,
              calories: workout.calories,
              steps: workout.steps,
            },
          })
        }
      >
        <WorkoutCard {...workout} />
      </TouchableOpacity>
    </View>
  );
};

export default WorkoutPlans;
