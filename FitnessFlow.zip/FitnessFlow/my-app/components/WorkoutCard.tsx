import React from "react";
import { View, Text, StyleSheet } from "react-native";

interface WorkoutCardProps {
  title: string;
  duration: string;
  calories: string;
  steps: string;
}

export default function WorkoutCard({
  title,
  duration,
  calories,
  steps,
}: WorkoutCardProps) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.detail}>
        Duration: <Text style={styles.value}>{duration}</Text>
      </Text>
      <Text style={styles.detail}>
        Calories: <Text style={styles.value}>{calories}</Text>
      </Text>
      <Text style={styles.detail}>
        Steps: <Text style={styles.value}>{steps}</Text>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#2a2a2a",
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    color: "#ffffff",
    marginBottom: 12,
  },
  detail: {
    fontSize: 16,
    color: "#cccccc",
    marginBottom: 4,
  },
  value: {
    color: "#ffffff",
    fontWeight: "500",
  },
});
