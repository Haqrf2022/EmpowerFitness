import { StatusBar } from "expo-status-bar";
import React from "react";
import { SafeAreaView, Text } from "react-native";

export default function App() {
  return (
    <SafeAreaView>
      <Text>Welcome to the Fitness App!</Text>
      <StatusBar style="auto" />
    </SafeAreaView>
  );
}
