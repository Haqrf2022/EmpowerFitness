// metro.config.js
const { getDefaultConfig } = require("expo/metro-config");

const config = getDefaultConfig(__dirname);

config.watchFolders = [__dirname];
config.server = { enhanceMiddleware: (middleware) => middleware };
config.projectRoot = __dirname;
config.watch = {
  usePolling: true,
  interval: 1000,
};

module.exports = config;
