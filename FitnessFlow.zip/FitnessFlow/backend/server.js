const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

// Import route modules
const authRoutes = require('./routes/auth');
const profileRoutes = require('./routes/profile');
const subscriptionRoutes = require('./routes/subscription');
const uploadRoutes = require('./routes/upload');
const notificationRoutes = require('./routes/notification');

// Initialize express app
const app = express();
const PORT = process.env.PORT || 8000;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(morgan('dev')); // Logging

// Static files for uploaded content
app.use('/uploads', express.static('uploads'));

// Welcome route
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to the Mobile App API' });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/subscription', subscriptionRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/notification', notificationRoutes);

// Import JWT error handler
const { handleJwtErrors } = require('./middleware/auth');

// JWT error handling middleware
app.use(handleJwtErrors);

// General error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: true,
    message: err.message || 'Something went wrong!',
  });
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
  
  // Log environment configuration for debugging
  console.log('Environment:');
  console.log(`- Node Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`- Supabase: ${process.env.SUPABASE_URL ? 'Configured' : 'Missing'}`);
  console.log(`- Auth0: ${process.env.AUTH0_DOMAIN ? 'Configured' : 'Missing'}`);
  console.log(`- AWS S3: ${process.env.AWS_ACCESS_KEY_ID ? 'Configured' : 'Missing'}`);
  console.log(`- Stripe: ${process.env.STRIPE_SECRET_KEY ? 'Configured' : 'Missing'}`);
  console.log(`- APNs: ${process.env.APNS_KEY_ID ? 'Configured' : 'Missing'}`);
});
