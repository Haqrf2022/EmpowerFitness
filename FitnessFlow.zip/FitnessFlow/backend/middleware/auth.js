// Import express-jwt library - comment out during development
//const { expressjwt: jwt } = require('express-jwt');
//const jwksRsa = require('jwks-rsa');

// Create our authentication middleware
const checkJwt = (req, res, next) => {
  // Check for Auth0 credentials in environment
  if (process.env.AUTH0_DOMAIN && process.env.AUTH0_AUDIENCE) {
    // In a real production environment, this would use the Auth0 JWT validation
    // We're providing this commented code for reference when real auth is implemented
    /*
    const jwtMiddleware = jwt({
      secret: jwksRsa.expressJwtSecret({
        cache: true,
        rateLimit: true,
        jwksRequestsPerMinute: 5,
        jwksUri: `https://${process.env.AUTH0_DOMAIN}/.well-known/jwks.json`
      }),
      audience: process.env.AUTH0_AUDIENCE,
      issuer: `https://${process.env.AUTH0_DOMAIN}/`,
      algorithms: ['RS256']
    });
    
    // Call the real middleware
    return jwtMiddleware(req, res, next);
    */
  }
  
  // For development: Mock JWT validation middleware
  console.warn('Using mock authentication middleware');
  
  // Check for Authorization header
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'No authorization token was found',
      error: 'No authorization token was found'
    });
  }
  
  // If we have a token, setup a mock user for development
  req.user = {
    sub: 'mock-user-id-123',
    scope: 'read:all write:all',
    name: 'Mock User',
    email: 'mock@example.com'
  };
  
  next();
}

// Middleware to check if user has the required scope
const checkScopes = (requiredScopes) => {
  return (req, res, next) => {
    if (!req.user || !req.user.scope) {
      return res.status(403).json({
        success: false,
        message: 'Permission denied: Missing user scopes'
      });
    }

    const tokenScopes = req.user.scope.split(' ');
    const hasRequiredScopes = requiredScopes.every(scope => tokenScopes.includes(scope));

    if (!hasRequiredScopes) {
      return res.status(403).json({
        success: false,
        message: 'Permission denied: Insufficient privileges'
      });
    }

    next();
  };
};

// Middleware to handle JWT errors
const handleJwtErrors = (err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired token',
      error: err.message
    });
  }
  
  next(err);
};

module.exports = {
  checkJwt,
  checkScopes,
  handleJwtErrors
};
