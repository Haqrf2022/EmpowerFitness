const express = require('express');
const router = express.Router();
const multer = require('multer');
const { checkJwt } = require('../middleware/auth');
const { uploadToS3 } = require('../services/s3');
const { supabase } = require('../services/supabase');

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Accept only images
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'), false);
    }
  },
});

/**
 * @route POST /api/upload
 * @desc Upload a file to S3 and save content to database
 * @access Private
 */
router.post('/', checkJwt, upload.single('file'), async (req, res) => {
  try {
    const file = req.file;
    const { caption, userId } = req.body;

    // Verify the user is uploading for themselves
    if (req.user.sub !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to upload for this user'
      });
    }

    // If no file was provided, just create a text post
    if (!file) {
      if (!caption || caption.trim() === '') {
        return res.status(400).json({
          success: false,
          message: 'Either a file or caption is required'
        });
      }

      // Create text-only content
      const { data, error } = await supabase
        .from('content')
        .insert([{
          user_id: userId,
          content: caption,
          created_at: new Date().toISOString()
        }])
        .select();

      if (error) throw error;

      return res.status(201).json({
        success: true,
        message: 'Content created successfully',
        content: data[0]
      });
    }

    // Upload file to S3
    const uniqueFilename = `${userId}/${Date.now()}-${file.originalname.replace(/\s+/g, '-')}`;
    const uploadResult = await uploadToS3(file.buffer, uniqueFilename, file.mimetype);

    // Create content entry in database
    const { data, error } = await supabase
      .from('content')
      .insert([{
        user_id: userId,
        content: caption || null,
        image_url: uploadResult.Location,
        s3_key: uploadResult.Key,
        created_at: new Date().toISOString()
      }])
      .select();

    if (error) throw error;

    res.status(201).json({
      success: true,
      message: 'File uploaded and content created successfully',
      content: data[0],
      fileUrl: uploadResult.Location
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({
      success: false,
      message: 'Error uploading file',
      error: error.message
    });
  }
});

/**
 * @route DELETE /api/upload/:contentId
 * @desc Delete content and associated file
 * @access Private
 */
router.delete('/:contentId', checkJwt, async (req, res) => {
  try {
    const { contentId } = req.params;
    const userId = req.user.sub;

    // Get content to verify ownership and get S3 key
    const { data: content, error: fetchError } = await supabase
      .from('content')
      .select('user_id, s3_key')
      .eq('id', contentId)
      .single();

    if (fetchError) {
      if (fetchError.code === 'PGRST116') {
        return res.status(404).json({
          success: false,
          message: 'Content not found'
        });
      }
      throw fetchError;
    }

    // Verify ownership
    if (content.user_id !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to delete this content'
      });
    }

    // Delete from S3 if there's a file
    if (content.s3_key) {
      await deleteFromS3(content.s3_key);
    }

    // Delete from database
    const { error: deleteError } = await supabase
      .from('content')
      .delete()
      .eq('id', contentId);

    if (deleteError) throw deleteError;

    res.status(200).json({
      success: true,
      message: 'Content deleted successfully'
    });
  } catch (error) {
    console.error('Delete content error:', error);
    res.status(500).json({
      success: false,
      message: 'Error deleting content',
      error: error.message
    });
  }
});

module.exports = router;
