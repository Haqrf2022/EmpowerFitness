const express = require('express');
const router = express.Router();
const { checkJwt } = require('../middleware/auth');
const { stripe } = require('../services/stripe');
const { supabase } = require('../services/supabase');

// Subscription plans
const SUBSCRIPTION_PLANS = [
  {
    id: 'basic',
    name: 'Basic Plan',
    price: 999, // $9.99
    features: [
      'Basic content access',
      'Standard resolution',
      'Email support'
    ],
    stripe_price_id: process.env.STRIPE_BASIC_PLAN_ID
  },
  {
    id: 'premium',
    name: 'Premium Plan',
    price: 1999, // $19.99
    features: [
      'Full content access',
      'HD resolution',
      'Priority support',
      'No ads'
    ],
    stripe_price_id: process.env.STRIPE_PREMIUM_PLAN_ID
  }
];

/**
 * @route GET /api/subscription/plans
 * @desc Get available subscription plans
 * @access Public
 */
router.get('/plans', (req, res) => {
  res.status(200).json({
    success: true,
    plans: SUBSCRIPTION_PLANS
  });
});

/**
 * @route GET /api/subscription/status/:userId
 * @desc Get subscription status for a user
 * @access Private
 */
router.get('/status/:userId', checkJwt, (req, res) => {
  try {
    const { userId } = req.params;
    
    // Verify the user is requesting their own subscription status
    if (req.user.sub !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to access this subscription status'
      });
    }

    // For development, we'll respond with mock subscription data
    // In production, this would fetch from Stripe and the database
    
    // 50% chance of having an active subscription for demonstration
    const mockSubscriptionActive = Math.random() > 0.5;
    
    if (!mockSubscriptionActive) {
      return res.status(200).json({
        success: true,
        status: 'inactive',
        subscription: null
      });
    }
    
    // Mock an active subscription
    const mockSubscription = {
      id: 'mock_sub_' + Date.now(),
      status: 'active',
      plan_id: 'price_basic',
      plan_name: 'Basic Plan',
      current_period_start: Math.floor(Date.now() / 1000) - 86400 * 15, // 15 days ago
      current_period_end: Math.floor(Date.now() / 1000) + 86400 * 15,   // 15 days from now
      cancel_at_period_end: false
    };

    res.status(200).json({
      success: true,
      status: 'active',
      subscription: mockSubscription
    });
  } catch (error) {
    console.error('Subscription status error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching subscription status',
      error: error.message
    });
  }
});

/**
 * @route POST /api/subscription/create
 * @desc Create a subscription for a user
 * @access Private
 */
router.post('/create', checkJwt, (req, res) => {
  try {
    const { planId, userId } = req.body;
    
    // Verify the user is creating their own subscription
    if (req.user.sub !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to create subscription for this user'
      });
    }

    // Find the plan
    const plan = SUBSCRIPTION_PLANS.find(p => p.id === planId);
    if (!plan) {
      return res.status(400).json({
        success: false,
        message: 'Invalid subscription plan'
      });
    }

    // For development, we'll create mock data
    // In production, this would interact with Stripe and the database
    
    // Create mock IDs
    const customerId = 'mock_customer_' + Date.now();
    const subscriptionId = 'mock_subscription_' + Date.now();
    const clientSecret = 'mock_client_secret_' + Date.now();
    const ephemeralKeySecret = 'mock_ephemeral_key_' + Date.now();

    // Return the mock data
    res.status(200).json({
      success: true,
      clientSecret: clientSecret,
      subscriptionId: subscriptionId,
      customerId: customerId,
      ephemeralKey: ephemeralKeySecret,
      plan: plan.name
    });
  } catch (error) {
    console.error('Subscription creation error:', error);
    res.status(500).json({
      success: false,
      message: 'Error creating subscription',
      error: error.message
    });
  }
});

/**
 * @route POST /api/subscription/cancel
 * @desc Cancel a subscription
 * @access Private
 */
router.post('/cancel', checkJwt, (req, res) => {
  try {
    const { subscriptionId } = req.body;
    const userId = req.user.sub;

    // For development, we'll just simulate a successful cancellation
    // In production, this would verify ownership and cancel the subscription with Stripe
    
    // Create a mock subscription response
    const mockSubscription = {
      id: subscriptionId || 'mock_sub_' + Date.now(),
      status: 'active',
      cancel_at_period_end: true,
      current_period_end: Math.floor(Date.now() / 1000) + 86400 * 15 // 15 days from now
    };

    res.status(200).json({
      success: true,
      message: 'Subscription will be canceled at the end of the billing period',
      subscription: mockSubscription
    });
  } catch (error) {
    console.error('Subscription cancellation error:', error);
    res.status(500).json({
      success: false,
      message: 'Error canceling subscription',
      error: error.message
    });
  }
});

/**
 * @route POST /api/subscription/webhook
 * @desc Handle Stripe webhook events
 * @access Public
 */
router.post('/webhook', express.json(), (req, res) => {
  // For development, we'll just log the webhook event and return a success response
  // In production, this would verify the signature and process Stripe webhooks
  
  console.log('Received mock webhook event:', req.body.type || 'unknown_event');
  
  // Always respond with a success message for testing
  res.status(200).json({ received: true });
});

module.exports = router;
