const express = require('express');
const router = express.Router();
const { checkJwt } = require('../middleware/auth');
const { supabase } = require('../services/supabase');

/**
 * @route GET /api/profile/:id
 * @desc Get a user's profile by ID
 * @access Public
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name, avatar_url, created_at')
      .eq('id', id)
      .single();

    if (error) throw error;

    if (!data) {
      return res.status(404).json({
        success: false,
        message: 'Profile not found'
      });
    }

    res.status(200).json({
      success: true,
      profile: data
    });
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching profile',
      error: error.message
    });
  }
});

/**
 * @route PUT /api/profile
 * @desc Update the current user's profile
 * @access Private
 */
router.put('/', checkJwt, async (req, res) => {
  try {
    const userId = req.user.sub;
    const { full_name, bio, website } = req.body;

    // Fields to update
    const updateData = {
      updated_at: new Date().toISOString()
    };

    // Only include fields that were provided
    if (full_name !== undefined) updateData.full_name = full_name;
    if (bio !== undefined) updateData.bio = bio;
    if (website !== undefined) updateData.website = website;

    const { data, error } = await supabase
      .from('profiles')
      .update(updateData)
      .eq('id', userId)
      .select();

    if (error) throw error;

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      profile: data[0]
    });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating profile',
      error: error.message
    });
  }
});

/**
 * @route GET /api/profile
 * @desc Get profiles with pagination
 * @access Public
 */
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const { data, error, count } = await supabase
      .from('profiles')
      .select('id, full_name, avatar_url, created_at', { count: 'exact' })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    res.status(200).json({
      success: true,
      profiles: data,
      pagination: {
        total: count,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(count / limit)
      }
    });
  } catch (error) {
    console.error('Profile list error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching profiles',
      error: error.message
    });
  }
});

module.exports = router;
