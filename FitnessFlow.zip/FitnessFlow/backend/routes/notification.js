const express = require('express');
const router = express.Router();
const { checkJwt } = require('../middleware/auth');
const { sendNotification } = require('../services/apns');
const { supabase } = require('../services/supabase');

/**
 * @route POST /api/notification/register-device
 * @desc Register a device token for push notifications
 * @access Private
 */
router.post('/register-device', checkJwt, async (req, res) => {
  try {
    const { deviceToken, deviceType = 'ios', userId } = req.body;
    
    // Validate request
    if (!deviceToken) {
      return res.status(400).json({
        success: false,
        message: 'Device token is required'
      });
    }
    
    // Verify the user is registering their own device
    if (req.user.sub !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to register device for this user'
      });
    }

    // Check if the device is already registered
    const { data: existingDevice, error: fetchError } = await supabase
      .from('device_tokens')
      .select('*')
      .eq('device_token', deviceToken)
      .eq('user_id', userId)
      .single();

    if (fetchError && fetchError.code !== 'PGRST116') {
      throw fetchError;
    }

    if (existingDevice) {
      // Update existing device
      const { data, error } = await supabase
        .from('device_tokens')
        .update({
          device_type: deviceType,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingDevice.id)
        .select();

      if (error) throw error;
      
      res.status(200).json({
        success: true,
        message: 'Device token updated successfully',
        device: data[0]
      });
    } else {
      // Register new device
      const { data, error } = await supabase
        .from('device_tokens')
        .insert([{
          user_id: userId,
          device_token: deviceToken,
          device_type: deviceType,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select();

      if (error) throw error;
      
      res.status(201).json({
        success: true,
        message: 'Device token registered successfully',
        device: data[0]
      });
    }
  } catch (error) {
    console.error('Device registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Error registering device',
      error: error.message
    });
  }
});

/**
 * @route POST /api/notification/send
 * @desc Send a push notification to a specific user
 * @access Private (Admin only)
 */
router.post('/send', checkJwt, async (req, res) => {
  try {
    const { userId, title, body, data } = req.body;
    
    // Validate request
    if (!userId || !title || !body) {
      return res.status(400).json({
        success: false,
        message: 'User ID, title, and body are required'
      });
    }

    // Get user's device tokens
    const { data: devices, error } = await supabase
      .from('device_tokens')
      .select('device_token, device_type')
      .eq('user_id', userId);

    if (error) throw error;

    if (!devices || devices.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No devices registered for this user'
      });
    }

    // Send notifications to all user devices
    const results = await Promise.all(
      devices.map(async (device) => {
        try {
          if (device.device_type === 'ios') {
            return await sendNotification(device.device_token, title, body, data);
          }
          // Add support for other device types as needed (FCM for Android, etc.)
          return { success: false, message: 'Unsupported device type' };
        } catch (err) {
          return { success: false, error: err.message };
        }
      })
    );

    // Count successful notifications
    const successCount = results.filter(r => r.success).length;

    res.status(200).json({
      success: true,
      message: `Notification sent to ${successCount} of ${devices.length} devices`,
      results
    });
  } catch (error) {
    console.error('Send notification error:', error);
    res.status(500).json({
      success: false,
      message: 'Error sending notification',
      error: error.message
    });
  }
});

/**
 * @route DELETE /api/notification/devices/:deviceToken
 * @desc Unregister a device token
 * @access Private
 */
router.delete('/devices/:deviceToken', checkJwt, async (req, res) => {
  try {
    const { deviceToken } = req.params;
    const userId = req.user.sub;

    // Delete device token
    const { error } = await supabase
      .from('device_tokens')
      .delete()
      .eq('device_token', deviceToken)
      .eq('user_id', userId);

    if (error) throw error;

    res.status(200).json({
      success: true,
      message: 'Device token unregistered successfully'
    });
  } catch (error) {
    console.error('Unregister device error:', error);
    res.status(500).json({
      success: false,
      message: 'Error unregistering device',
      error: error.message
    });
  }
});

module.exports = router;
