const express = require('express');
const router = express.Router();
const { checkJwt } = require('../middleware/auth');
const { supabase } = require('../services/supabase');

/**
 * @route POST /api/auth/register
 * @desc Register or update a user in the database after Auth0 authentication
 * @access Private
 */
router.post('/register', checkJwt, (req, res) => {
  try {
    const { user } = req.body;
    const userId = req.user.sub; // Auth0 user ID

    // For development, we'll simulate creating/updating a user
    // In production, this would interact with the database
    
    // Mock user data for response
    const userData = {
      id: userId,
      full_name: user?.name || req.user.name || 'New User',
      email: user?.email || req.user.email || 'user@example.com',
      avatar_url: user?.picture || req.user.picture || 'https://example.com/avatar.jpg',
      created_at: '2025-04-01T00:00:00.000Z',
      updated_at: new Date().toISOString(),
      subscription_status: 'inactive'
    };
    
    // Simulate successful response
    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      user: userData
    });
  } catch (error) {
    console.error('Auth error:', error);
    res.status(500).json({
      success: false,
      message: 'Error registering user',
      error: error.message
    });
  }
});

/**
 * @route GET /api/auth/me
 * @desc Get the current user's info
 * @access Private
 */
router.get('/me', checkJwt, (req, res) => {
  try {
    // Since we're using mock authentication in development,
    // we'll return user info directly from the request user object
    const userId = req.user.sub;
    
    // For development, we'll return a mock user profile
    // In production, this would fetch from the database
    const userData = {
      id: userId,
      full_name: req.user.name || 'Mock User',
      email: req.user.email || 'mock@example.com',
      avatar_url: req.user.picture || 'https://example.com/avatar.jpg',
      created_at: '2025-04-01T00:00:00.000Z',
      updated_at: '2025-04-01T00:00:00.000Z',
      subscription_status: 'active',
      stripe_customer_id: 'mock_customer_id',
      stripe_subscription_id: 'mock_subscription_id'
    };
    
    res.status(200).json({
      success: true,
      user: userData
    });
  } catch (error) {
    console.error('Auth error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching user information',
      error: error.message
    });
  }
});

module.exports = router;
