const Stripe = require('stripe');

// Initialize Stripe with the secret key
const stripeSecretKey = process.env.STRIPE_SECRET_KEY;

// Create mock stripe object if key is missing
let stripe = null;

if (!stripeSecretKey) {
  console.warn('Stripe secret key is missing. Payment features will be disabled.');
  // Mock stripe object with dummy methods
  stripe = {
    customers: {
      create: async () => ({ id: 'mock_customer_id' })
    },
    subscriptions: {
      create: async () => ({ id: 'mock_subscription_id', latest_invoice: { payment_intent: { client_secret: 'mock_client_secret' } } }),
      retrieve: async () => ({ id: 'mock_subscription_id', status: 'inactive', items: { data: [{ price: { id: 'mock_price_id' } }] } }),
      update: async () => ({ id: 'mock_subscription_id', status: 'canceled', cancel_at_period_end: true }),
      cancel: async () => ({ id: 'mock_subscription_id', status: 'canceled' })
    },
    ephemeralKeys: {
      create: async () => ({ secret: 'mock_ephemeral_key_secret' })
    },
    paymentIntents: {
      create: async () => ({ id: 'mock_payment_intent_id', client_secret: 'mock_client_secret' })
    },
    webhooks: {
      constructEvent: () => ({ type: 'unknown', data: { object: {} } })
    }
  };
} else {
  stripe = new Stripe(stripeSecretKey, {
    apiVersion: '2022-11-15', // Use a compatible API version
  });
}

/**
 * Create a Stripe customer
 * @param {Object} userData - User data
 * @returns {Promise<Object>} Stripe customer object
 */
const createCustomer = async (userData) => {
  try {
    const customer = await stripe.customers.create({
      email: userData.email,
      name: userData.name,
      metadata: {
        userId: userData.id
      }
    });
    
    return customer;
  } catch (error) {
    console.error('Error creating Stripe customer:', error);
    throw error;
  }
};

/**
 * Create a subscription
 * @param {string} customerId - Stripe customer ID
 * @param {string} priceId - Stripe price ID
 * @returns {Promise<Object>} Stripe subscription object
 */
const createSubscription = async (customerId, priceId) => {
  try {
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      payment_behavior: 'default_incomplete',
      payment_settings: { save_default_payment_method: 'on_subscription' },
      expand: ['latest_invoice.payment_intent'],
    });
    
    return subscription;
  } catch (error) {
    console.error('Error creating Stripe subscription:', error);
    throw error;
  }
};

/**
 * Cancel a subscription
 * @param {string} subscriptionId - Stripe subscription ID
 * @param {boolean} immediately - Whether to cancel immediately or at period end
 * @returns {Promise<Object>} Stripe subscription object
 */
const cancelSubscription = async (subscriptionId, immediately = false) => {
  try {
    if (immediately) {
      // Cancel immediately
      return await stripe.subscriptions.cancel(subscriptionId);
    } else {
      // Cancel at period end
      return await stripe.subscriptions.update(subscriptionId, {
        cancel_at_period_end: true
      });
    }
  } catch (error) {
    console.error('Error canceling Stripe subscription:', error);
    throw error;
  }
};

/**
 * Create a payment intent
 * @param {number} amount - Amount in cents
 * @param {string} currency - Currency code (default: 'usd')
 * @param {Object} metadata - Additional metadata
 * @returns {Promise<Object>} Stripe payment intent object
 */
const createPaymentIntent = async (amount, currency = 'usd', metadata = {}) => {
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
      metadata,
    });
    
    return paymentIntent;
  } catch (error) {
    console.error('Error creating Stripe payment intent:', error);
    throw error;
  }
};

/**
 * Create an ephemeral key
 * @param {string} customerId - Stripe customer ID
 * @returns {Promise<Object>} Ephemeral key object
 */
const createEphemeralKey = async (customerId) => {
  try {
    const ephemeralKey = await stripe.ephemeralKeys.create(
      { customer: customerId },
      { apiVersion: '2022-11-15' }
    );
    
    return ephemeralKey;
  } catch (error) {
    console.error('Error creating Stripe ephemeral key:', error);
    throw error;
  }
};

module.exports = {
  stripe,
  createCustomer,
  createSubscription,
  cancelSubscription,
  createPaymentIntent,
  createEphemeralKey
};
