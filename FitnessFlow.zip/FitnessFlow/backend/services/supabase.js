// Import Supabase client - only when actually used
let createClient;
try {
  // This might fail if the package isn't available, which is fine for development
  ({ createClient } = require('@supabase/supabase-js'));
} catch (error) {
  console.warn('Supabase JS library not loaded. Using mock client only.');
  createClient = null;
}

// Initialize Supabase client with defaults for development
const supabaseUrl = process.env.SUPABASE_URL || 'https://example.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV4YW1wbGVrZXkiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTYwMDAwMDAwMCwiZXhwIjoxNjAwMDAwMDAwfQ.invalid-key-for-development-only';

let supabase;

// Use mock client if we're using default values
if (!process.env.SUPABASE_URL || !process.env.SUPABASE_KEY) {
  console.warn('Supabase URL or key is missing. Using mock Supabase client.');
  
  // Create a mock supabase client with more realistic data for development
  const mockData = {
    profiles: [
      {
        id: 'mock-user-id-123',
        full_name: 'Mock User',
        email: 'mock@example.com',
        avatar_url: 'https://example.com/avatar.jpg',
        created_at: '2025-04-01T00:00:00.000Z',
        updated_at: '2025-04-01T00:00:00.000Z',
        subscription_status: 'active',
        stripe_customer_id: 'mock_customer_id',
        stripe_subscription_id: 'mock_subscription_id'
      }
    ],
    content: [],
    device_tokens: []
  };
  
  supabase = {
    from: (table) => ({
      select: (columns, options) => ({
        eq: (column, value) => ({
          single: () => {
            // Find the item in our mock data
            const item = mockData[table]?.find(item => item[column] === value);
            if (item) {
              return Promise.resolve({ data: item, error: null });
            } else {
              return Promise.resolve({ data: null, error: { code: 'PGRST116', message: 'Item not found' } });
            }
          },
          range: (start, end) => Promise.resolve({ data: mockData[table] || [], error: null, count: mockData[table]?.length || 0 }),
          then: () => Promise.resolve({ data: mockData[table]?.filter(item => item[column] === value) || [], error: null })
        }),
        then: () => Promise.resolve({ data: mockData[table] || [], error: null, count: mockData[table]?.length || 0 })
      }),
      insert: (data) => ({
        select: () => {
          // Add the items to our mock data
          if (!mockData[table]) {
            mockData[table] = [];
          }
          
          const newItems = Array.isArray(data) ? data : [data];
          const insertedItems = newItems.map(item => {
            const newItem = { ...item, id: item.id || `mock-${table}-${Date.now()}` };
            mockData[table].push(newItem);
            return newItem;
          });
          
          return Promise.resolve({ data: insertedItems, error: null });
        }
      }),
      update: (data) => ({
        eq: (column, value) => ({
          select: () => {
            // Update the item in our mock data
            if (!mockData[table]) {
              return Promise.resolve({ data: [], error: null });
            }
            
            const index = mockData[table].findIndex(item => item[column] === value);
            if (index !== -1) {
              mockData[table][index] = { ...mockData[table][index], ...data, updated_at: new Date().toISOString() };
              return Promise.resolve({ data: [mockData[table][index]], error: null });
            } else {
              return Promise.resolve({ data: [], error: null });
            }
          }
        })
      }),
      delete: () => ({
        eq: (column, value) => {
          // Remove the item from our mock data
          if (mockData[table]) {
            const initialLength = mockData[table].length;
            mockData[table] = mockData[table].filter(item => item[column] !== value);
            const deleted = initialLength - mockData[table].length;
            return Promise.resolve({ data: { deleted }, error: null });
          }
          return Promise.resolve({ data: { deleted: 0 }, error: null });
        }
      })
    }),
    storage: {
      from: (bucket) => ({
        upload: (path, file) => Promise.resolve({ 
          data: { path, key: path }, 
          error: null 
        }),
        getPublicUrl: (path) => ({ 
          data: { publicUrl: `https://example.com/${bucket}/${path}` } 
        })
      })
    },
    rpc: (func, params) => Promise.resolve({ data: null, error: null })
  };
} else {
  // Make sure we have a valid URL format
  const validUrl = supabaseUrl.startsWith('http') ? supabaseUrl : `https://${supabaseUrl}`;
  supabase = createClient(validUrl, supabaseKey);
}

/**
 * Initialize database schema if needed
 */
const initializeSchema = async () => {
  try {
    // Check if profiles table exists
    const { data: profilesExists, error: profilesError } = await supabase
      .from('profiles')
      .select('id', { count: 'exact', head: true });
    
    if (profilesError && profilesError.code !== 'PGRST116') {
      // Create profiles table
      await supabase.rpc('create_profiles_table');
    }
    
    // Check if content table exists
    const { data: contentExists, error: contentError } = await supabase
      .from('content')
      .select('id', { count: 'exact', head: true });
    
    if (contentError && contentError.code !== 'PGRST116') {
      // Create content table
      await supabase.rpc('create_content_table');
    }
    
    // Check if device_tokens table exists
    const { data: deviceTokensExists, error: deviceTokensError } = await supabase
      .from('device_tokens')
      .select('id', { count: 'exact', head: true });
    
    if (deviceTokensError && deviceTokensError.code !== 'PGRST116') {
      // Create device_tokens table
      await supabase.rpc('create_device_tokens_table');
    }
    
    console.log('Database schema initialized successfully.');
  } catch (error) {
    console.error('Error initializing database schema:', error);
    throw error;
  }
};

// Helper function to get or create user profile
const getOrCreateProfile = async (userId, userData) => {
  try {
    // Try to get existing profile
    const { data: existingProfile, error: fetchError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (fetchError && fetchError.code !== 'PGRST116') {
      throw fetchError;
    }
    
    if (existingProfile) {
      return existingProfile;
    }
    
    // Create new profile
    const newProfile = {
      id: userId,
      full_name: userData.name || '',
      email: userData.email || '',
      avatar_url: userData.picture || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    const { data: createdProfile, error: createError } = await supabase
      .from('profiles')
      .insert([newProfile])
      .select();
    
    if (createError) {
      throw createError;
    }
    
    return createdProfile[0];
  } catch (error) {
    console.error('Error in getOrCreateProfile:', error);
    throw error;
  }
};

// Update user's Stripe customer ID
const updateStripeCustomerId = async (userId, customerId) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .update({ stripe_customer_id: customerId })
      .eq('id', userId)
      .select();
    
    if (error) throw error;
    
    return data[0];
  } catch (error) {
    console.error('Error updating Stripe customer ID:', error);
    throw error;
  }
};

// Update user's Stripe subscription info
const updateUserStripeInfo = async (userId, stripeInfo) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .update({
        stripe_customer_id: stripeInfo.customerId,
        stripe_subscription_id: stripeInfo.subscriptionId,
        subscription_status: 'active',
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)
      .select();
    
    if (error) throw error;
    
    return data[0];
  } catch (error) {
    console.error('Error updating user Stripe info:', error);
    throw error;
  }
};

module.exports = {
  supabase,
  initializeSchema,
  getOrCreateProfile,
  updateStripeCustomerId,
  updateUserStripeInfo
};
