const AWS = require('aws-sdk');

// Check for AWS credentials
const haveAwsCredentials = process.env.AWS_ACCESS_KEY_ID && 
                           process.env.AWS_SECRET_ACCESS_KEY && 
                           process.env.AWS_S3_BUCKET;

let s3;
const bucketName = process.env.AWS_S3_BUCKET;

if (haveAwsCredentials) {
  // Configure AWS with real credentials
  AWS.config.update({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION || 'us-east-1'
  });
  
  // Initialize real S3 client
  s3 = new AWS.S3();
} else {
  console.warn('AWS credentials or bucket name is missing. Using mock S3 functionality.');
  
  // Mock S3 client
  s3 = {
    upload: (params) => ({
      promise: () => Promise.resolve({
        Location: `https://example.com/mock-s3/${params.Key}`,
        Key: params.Key,
        Bucket: params.Bucket
      })
    }),
    deleteObject: (params) => ({
      promise: () => Promise.resolve({ })
    }),
    getSignedUrlPromise: (operation, params) => {
      return Promise.resolve(`https://example.com/mock-s3/${params.Key}?signed=true`);
    }
  };
}

/**
 * Upload a file to AWS S3
 * @param {Buffer} fileBuffer - File data as buffer
 * @param {string} fileName - Name to use for the file
 * @param {string} contentType - MIME type of the file
 * @returns {Promise<Object>} S3 upload result
 */
const uploadToS3 = async (fileBuffer, fileName, contentType) => {
  try {
    const params = {
      Bucket: bucketName,
      Key: fileName,
      Body: fileBuffer,
      ContentType: contentType,
      ACL: 'public-read', // Make the file publicly accessible
    };

    const data = await s3.upload(params).promise();
    return data;
  } catch (error) {
    console.error('S3 upload error:', error);
    throw error;
  }
};

/**
 * Delete a file from AWS S3
 * @param {string} key - S3 key of the file to delete
 * @returns {Promise<Object>} S3 delete result
 */
const deleteFromS3 = async (key) => {
  try {
    const params = {
      Bucket: bucketName,
      Key: key,
    };

    const data = await s3.deleteObject(params).promise();
    return data;
  } catch (error) {
    console.error('S3 delete error:', error);
    throw error;
  }
};

/**
 * Generate a signed URL for temporary access to a private file
 * @param {string} key - S3 key of the file
 * @param {number} expirySeconds - Seconds until URL expires (default: 60)
 * @returns {Promise<string>} Signed URL
 */
const getSignedUrl = async (key, expirySeconds = 60) => {
  try {
    const params = {
      Bucket: bucketName,
      Key: key,
      Expires: expirySeconds,
    };

    const url = await s3.getSignedUrlPromise('getObject', params);
    return url;
  } catch (error) {
    console.error('S3 signed URL error:', error);
    throw error;
  }
};

module.exports = {
  s3,
  uploadToS3,
  deleteFromS3,
  getSignedUrl
};
