const apn = require('apn');

// Initialize APNs provider
let apnProvider = null;
const Notification = apn.Notification; // Keep a reference to the Notification class

// Check for required APNs configuration and key file
if (!process.env.APNS_KEY_ID || !process.env.APNS_TEAM_ID || !process.env.APNS_KEY_PATH) {
  console.warn('APNs configuration is missing. Using mock push notification functionality.');
  
  // Create a mock provider with the same interface
  apnProvider = {
    send: (notification, deviceToken) => {
      console.log(`[MOCK] Would send notification to device: ${deviceToken}`);
      console.log(`[MOCK] Notification: ${notification.alert?.title} - ${notification.alert?.body}`);
      
      return Promise.resolve({
        sent: [{ device: deviceToken }],
        failed: []
      });
    },
    shutdown: () => {
      console.log('[MOCK] APNs provider shut down');
    }
  };
} else {
  try {
    // Only attempt to initialize real provider if APNS_KEY_PATH is a real file path
    const apnOptions = {
      token: {
        key: process.env.APNS_KEY_PATH, 
        keyId: process.env.APNS_KEY_ID,
        teamId: process.env.APNS_TEAM_ID,
      },
      production: process.env.NODE_ENV === 'production',
    };

    apnProvider = new apn.Provider(apnOptions);
    console.log('APNs provider initialized successfully.');
  } catch (error) {
    console.error('Error initializing APNs provider:', error);
    
    // Fallback to mock provider on initialization error
    apnProvider = {
      send: (notification, deviceToken) => {
        console.log(`[MOCK-FALLBACK] Would send notification to device: ${deviceToken}`);
        return Promise.resolve({
          sent: [{ device: deviceToken }],
          failed: []
        });
      },
      shutdown: () => {}
    };
  }
}

/**
 * Send a push notification to an iOS device
 * @param {string} deviceToken - APNs device token
 * @param {string} title - Notification title
 * @param {string} body - Notification body
 * @param {Object} data - Additional data to send with the notification
 * @returns {Promise<Object>} Notification result
 */
const sendNotification = async (deviceToken, title, body, data = {}) => {
  if (!apnProvider) {
    throw new Error('APNs provider is not initialized.');
  }

  try {
    // Determine if we're using real or mock provider
    const useMockProvider = !process.env.APNS_KEY_ID || !process.env.APNS_TEAM_ID || !process.env.APNS_KEY_PATH;
    
    // For mock provider, create a simple notification object
    let notification;
    if (useMockProvider) {
      notification = {
        expiry: Math.floor(Date.now() / 1000) + 3600,
        badge: 1,
        sound: 'default',
        alert: {
          title,
          body,
        },
        topic: process.env.APNS_BUNDLE_ID || 'com.example.app',
        payload: data
      };
    } else {
      // Create a real APN notification 
      notification = new apn.Notification();
      
      // Set basic notification properties
      notification.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires in 1 hour
      notification.badge = 1;
      notification.sound = 'default';
      notification.alert = {
        title,
        body,
      };
      notification.topic = process.env.APNS_BUNDLE_ID; // Your app's bundle ID
      
      // Add custom data if provided
      if (data && Object.keys(data).length > 0) {
        notification.payload = data;
      }
    }
    
    // Send the notification
    const result = await apnProvider.send(notification, deviceToken);
    
    // Check for errors
    if (result.failed.length > 0) {
      const error = result.failed[0].response;
      throw new Error(error ? error.reason || 'Unknown error' : 'Unknown error');
    }
    
    return {
      success: true,
      sent: result.sent.length,
      failed: result.failed.length,
    };
  } catch (error) {
    console.error('Error sending APNs notification:', error);
    throw error;
  }
};

/**
 * Shutdown the APNs provider
 */
const shutdownAPNs = () => {
  if (apnProvider) {
    apnProvider.shutdown();
    console.log('APNs provider shut down.');
  }
};

module.exports = {
  sendNotification,
  shutdownAPNs
};
