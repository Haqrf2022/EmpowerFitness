import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

const ProfileCard = ({   name,
                     avatar,
                     content,
                     imageUrl,
                     timestamp,
                     workoutType,
                     duration,
                     caloriesBurned,
                     goal,
                     onLike,
 }) => {
  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Image 
          source={{ uri: avatar || 'https://via.placeholder.com/40' }} 
          style={styles.avatar} 
        />
        <View style={styles.nameContainer}>
          <Text style={styles.name}>{name}</Text>
          <Text style={styles.timestamp}>{timestamp}</Text>
        </View>
      </View>

      {content && (
        <Text style={styles.content}>{content}</Text>
      <View style={styles.fitnessInfo}>
        {workoutType && <Text style={styles.fitnessText}>🏋️ Workout: {workoutType}</Text>}
        {duration && <Text style={styles.fitnessText}>⏱ Duration: {duration} mins</Text>}
        {caloriesBurned && <Text style={styles.fitnessText}>🔥 Calories: {caloriesBurned}</Text>}
        {goal && <Text style={styles.fitnessText}>🎯 Goal: {goal}</Text>}
      </View>
      )}

      {imageUrl && (
        <Image source={{ uri: imageUrl }} style={styles.contentImage} />
      )}

      <View style={styles.actionContainer}>
        <TouchableOpacity style={styles.actionButton} onPress={onLike}>
          <Icon name="heart" size={20} color="#757575" />
          <Text style={styles.actionText}>Like</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.actionButton}>
          <Icon name="message-circle" size={20} color="#757575" />
          <Text style={styles.actionText}>Comment</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.actionButton}>
          <Icon name="share-2" size={20} color="#757575" />
          <Text style={styles.actionText}>Share</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
    elevation: 2,
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  nameContainer: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  timestamp: {
    fontSize: 12,
    color: '#757575',
    marginTop: 2,
  },
  content: {
    fontSize: 16,
    color: '#212121',
    marginBottom: 12,
  },
  contentImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginBottom: 12,
    resizeMode: 'cover',
  },
  actionContainer: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: {
    fontSize: 14,
    color: '#757575',
    marginLeft: 4,
  },
  fitnessInfo: {
    marginBottom: 8,
  },
  fitnessText: {
    fontSize: 14,
    color: '#424242',
    marginTop: 2,
  },
});

export default ProfileCard;
