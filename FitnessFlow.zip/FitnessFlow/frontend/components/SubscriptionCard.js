import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import Button from './Button';

const SubscriptionCard = ({ 
  title, 
  price, 
  features, 
  selected, 
  onSelect, 
  onSubscribe, 
  disabled 
}) => {
  return (
    <TouchableOpacity 
      style={[
        styles.container, 
        selected && styles.selectedContainer
      ]} 
      onPress={onSelect}
      disabled={disabled}
    >
      <View style={styles.headerContainer}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.price}>{price}</Text>
      </View>

      <View style={styles.featuresContainer}>
        {features.map((feature, index) => (
          <View key={index} style={styles.featureItem}>
            <Icon name="check" size={16} color="#6200ee" />
            <Text style={styles.featureText}>{feature}</Text>
          </View>
        ))}
      </View>

      <Button 
        title="Subscribe" 
        onPress={onSubscribe}
        style={[
          styles.subscribeButton, 
          selected && styles.selectedButton
        ]}
        disabled={disabled}
      />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  selectedContainer: {
    borderColor: '#6200ee',
    borderWidth: 2,
    shadowColor: '#6200ee',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  headerContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  price: {
    fontSize: 24,
    fontWeight: '600',
    color: '#6200ee',
  },
  featuresContainer: {
    marginBottom: 16,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  featureText: {
    fontSize: 16,
    marginLeft: 8,
  },
  subscribeButton: {
    backgroundColor: '#6200ee',
  },
  selectedButton: {
    backgroundColor: '#3700b3',
  },
});

export default SubscriptionCard;
