import { Platform } from 'react-native';

// Base URL for the API
const API_BASE_URL = Platform.OS === 'web' 
  ? 'http://localhost:8000' 
  : 'http://10.0.2.2:8000'; // Use 10.0.2.2 for Android emulator, localhost for web

/**
 * Generic API request function
 * @param {string} method - HTTP method (GET, POST, PUT, DELETE)
 * @param {string} endpoint - API endpoint (e.g., '/api/users')
 * @param {object} data - Request payload (for POST/PUT)
 * @param {string} token - Auth token (optional)
 * @param {boolean} isFormData - Whether the request contains form data
 * @returns {Promise<any>} Response data
 */
export const apiRequest = async (method, endpoint, data = null, token = null, isFormData = false) => {
  try {
    const url = `${API_BASE_URL}${endpoint}`;
    
    const headers = {
      'Accept': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` }),
      ...(!isFormData && { 'Content-Type': 'application/json' }),
    };
    
    const config = {
      method,
      headers,
      ...(data && method !== 'GET' && { 
        body: isFormData ? data : JSON.stringify(data) 
      }),
    };
    
    console.log(`Making ${method} request to ${url}`);
    
    const response = await fetch(url, config);
    
    // Handle HTTP errors
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `Request failed with status ${response.status}`);
    }
    
    // Check if response is JSON
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.indexOf('application/json') !== -1) {
      return await response.json();
    }
    
    return await response.text();
  } catch (error) {
    console.error('API request error:', error);
    throw error;
  }
};
