import React, { createContext, useState, useEffect, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Auth0 from 'react-native-auth0';
import { apiRequest } from '../services/api';

// Initialize Auth0 client
const auth0 = new Auth0({
  domain: process.env.AUTH0_DOMAIN || '',
  clientId: process.env.AUTH0_CLIENT_ID || '',
});

// Create the authentication context
const AuthContext = createContext();

// Custom hook to use the auth context
export const useAuth = () => {
  return useContext(AuthContext);
};

// Auth provider component to manage authentication state
export const AuthProvider = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [userToken, setUserToken] = useState(null);
  const [user, setUser] = useState(null);
  const [error, setError] = useState(null);

  // Check for existing token on app load
  useEffect(() => {
    const loadStoredToken = async () => {
      try {
        const token = await AsyncStorage.getItem('userToken');
        const userData = await AsyncStorage.getItem('userData');
        
        if (token && userData) {
          setUserToken(token);
          setUser(JSON.parse(userData));
        }
      } catch (e) {
        console.error('Failed to load authentication data:', e);
      } finally {
        setIsLoading(false);
      }
    };

    loadStoredToken();
  }, []);

  // Login with Auth0
  const login = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Authenticate with Auth0
      const credentials = await auth0.webAuth.authorize({
        scope: 'openid profile email',
      });
      
      // Get user profile from Auth0
      const userInfo = await auth0.auth.userInfo({ token: credentials.accessToken });
      
      // Store token and user info
      await AsyncStorage.setItem('userToken', credentials.idToken);
      await AsyncStorage.setItem('userData', JSON.stringify(userInfo));
      
      // Update state
      setUserToken(credentials.idToken);
      setUser(userInfo);
      
      // Register/update user on backend
      await apiRequest('POST', '/api/auth/register', { user: userInfo }, credentials.idToken);
      
      return { success: true };
    } catch (e) {
      console.error('Login error:', e);
      setError(e.message || 'Login failed');
      return { success: false, error: e.message };
    } finally {
      setIsLoading(false);
    }
  };

  // Logout
  const logout = async () => {
    setIsLoading(true);
    
    try {
      // Clear Auth0 session
      await auth0.webAuth.clearSession();
      
      // Remove stored data
      await AsyncStorage.removeItem('userToken');
      await AsyncStorage.removeItem('userData');
      
      // Update state
      setUserToken(null);
      setUser(null);
    } catch (e) {
      console.error('Logout error:', e);
      setError(e.message || 'Logout failed');
    } finally {
      setIsLoading(false);
    }
  };

  // Auth context value
  const authContextValue = {
    isLoading,
    userToken,
    user,
    error,
    login,
    logout,
    isAuthenticated: !!userToken,
  };

  return (
    <AuthContext.Provider value={authContextValue}>
      {children}
    </AuthContext.Provider>
  );
};
