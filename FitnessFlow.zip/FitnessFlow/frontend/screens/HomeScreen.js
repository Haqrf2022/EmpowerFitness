// components/ProfileCard.tsx

import React from "react";
import { View, Text, Image, StyleSheet } from "react-native";

interface ProfileCardProps {
  name: string;
  avatar: string;
  content: string;
  imageUrl?: string;
  timestamp: string;
  steps?: number;
  calories?: number;
  duration?: number;
}

const ProfileCard: React.FC<ProfileCardProps> = ({
  name,
  avatar,
  content,
  imageUrl,
  timestamp,
  steps,
  calories,
  duration,
}) => {
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <Image source={{ uri: avatar }} style={styles.avatar} />
        <View>
          <Text style={styles.name}>{name}</Text>
          <Text style={styles.timestamp}>{timestamp}</Text>
        </View>
      </View>

      <Text style={styles.content}>{content}</Text>

      {imageUrl ? (
        <Image source={{ uri: imageUrl }} style={styles.image} />
      ) : null}

      <View style={styles.metricsContainer}>
        {steps !== undefined && (
          <Text style={styles.metric}>Steps: {steps}</Text>
        )}
        {calories !== undefined && (
          <Text style={styles.metric}>Calories: {calories}</Text>
        )}
        {duration !== undefined && (
          <Text style={styles.metric}>Duration: {duration} min</Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    margin: 12,
    padding: 16,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  name: {
    fontWeight: "bold",
    fontSize: 16,
  },
  timestamp: {
    fontSize: 12,
    color: "#888",
  },
  content: {
    fontSize: 14,
    marginBottom: 10,
  },
  image: {
    width: "100%",
    height: 180,
    borderRadius: 8,
    marginTop: 8,
    marginBottom: 8,
  },
  metricsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 8,
  },
  metric: {
    fontSize: 14,
    color: "#555",
  },
});

export default ProfileCard;
