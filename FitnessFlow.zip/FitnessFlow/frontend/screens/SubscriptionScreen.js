import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useAuth } from '../context/AuthContext';
import SubscriptionCard from '../components/SubscriptionCard';
import Button from '../components/Button';
import { apiRequest } from '../services/api';
import { useStripe } from '@stripe/stripe-react-native';

const SubscriptionScreen = () => {
  const { user } = useAuth();
  const { initPaymentSheet, presentPaymentSheet } = useStripe();
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [subscriptionPlans, setSubscriptionPlans] = useState([]);
  const [currentSubscription, setCurrentSubscription] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState(null);

  // Fetch subscription plans and current subscription status
  useEffect(() => {
    const fetchSubscriptionData = async () => {
      try {
        setLoading(true);
        
        // Fetch subscription plans
        const plansResponse = await apiRequest('GET', '/api/subscription/plans');
        setSubscriptionPlans(plansResponse.plans || []);
        
        // Fetch user's current subscription
        if (user && user.sub) {
          const subResponse = await apiRequest('GET', `/api/subscription/status/${user.sub}`);
          setCurrentSubscription(subResponse.subscription || null);
        }
      } catch (error) {
        console.error('Error fetching subscription data:', error);
        Alert.alert('Error', 'Failed to load subscription information.');
      } finally {
        setLoading(false);
      }
    };

    fetchSubscriptionData();
  }, [user]);

  // Initialize the payment sheet
  const initializePayment = async (planId) => {
    if (!user || !user.sub) {
      Alert.alert('Error', 'You must be logged in to subscribe.');
      return false;
    }

    try {
      setProcessing(true);
      
      // Get payment intent from the server
      const { clientSecret, ephemeralKey, customerId } = await apiRequest(
        'POST', 
        '/api/subscription/create', 
        { planId, userId: user.sub }
      );
      
      // Initialize the payment sheet
      const { error } = await initPaymentSheet({
        merchantDisplayName: 'My Mobile App',
        customerId,
        customerEphemeralKeySecret: ephemeralKey,
        paymentIntentClientSecret: clientSecret,
        allowsDelayedPaymentMethods: false,
        defaultBillingDetails: {
          name: user.name,
          email: user.email,
        },
      });

      if (error) {
        console.error('Error initializing payment sheet:', error);
        Alert.alert('Error', error.message);
        return false;
      }
      
      return true;
    } catch (error) {
      console.error('Error creating payment intent:', error);
      Alert.alert('Error', 'Failed to initialize payment process.');
      return false;
    } finally {
      setProcessing(false);
    }
  };

  // Handle the subscription process
  const handleSubscribe = async (planId) => {
    // Initialize the payment sheet with the selected plan
    const initialized = await initializePayment(planId);
    if (!initialized) return;
    
    // Present the payment sheet to the user
    const { error } = await presentPaymentSheet();
    
    if (error) {
      console.error('Payment sheet error:', error);
      Alert.alert('Payment Failed', error.message);
    } else {
      // Payment succeeded, update subscription status
      try {
        const response = await apiRequest('GET', `/api/subscription/status/${user.sub}`);
        setCurrentSubscription(response.subscription || null);
        Alert.alert('Success', 'Your subscription has been activated!');
      } catch (updateError) {
        console.error('Error updating subscription status:', updateError);
      }
    }
  };

  // Handle cancellation of subscription
  const handleCancelSubscription = async () => {
    if (!currentSubscription || !currentSubscription.id) {
      Alert.alert('Error', 'No active subscription to cancel.');
      return;
    }

    Alert.alert(
      'Cancel Subscription',
      'Are you sure you want to cancel your subscription? This will take effect at the end of your current billing cycle.',
      [
        { text: 'No', style: 'cancel' },
        { 
          text: 'Yes, Cancel', 
          style: 'destructive',
          onPress: async () => {
            try {
              setProcessing(true);
              await apiRequest(
                'POST', 
                '/api/subscription/cancel', 
                { subscriptionId: currentSubscription.id }
              );
              
              // Update the subscription status
              const response = await apiRequest('GET', `/api/subscription/status/${user.sub}`);
              setCurrentSubscription(response.subscription || null);
              
              Alert.alert('Success', 'Your subscription has been canceled.');
            } catch (error) {
              console.error('Error canceling subscription:', error);
              Alert.alert('Error', 'Failed to cancel subscription.');
            } finally {
              setProcessing(false);
            }
          }
        }
      ]
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6200ee" />
        <Text style={styles.loadingText}>Loading subscription information...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Subscription Plans</Text>
        <Text style={styles.subtitle}>Choose the plan that's right for you</Text>
      </View>

      {currentSubscription && (
        <View style={styles.currentSubscription}>
          <Text style={styles.currentTitle}>Current Subscription</Text>
          <Text style={styles.planName}>{currentSubscription.plan_name || 'Premium Plan'}</Text>
          <Text style={styles.statusText}>
            Status: <Text style={styles.statusActive}>{currentSubscription.status || 'active'}</Text>
          </Text>
          {currentSubscription.current_period_end && (
            <Text style={styles.renewalText}>
              Renews on: {new Date(currentSubscription.current_period_end * 1000).toLocaleDateString()}
            </Text>
          )}
          
          <Button 
            title="Cancel Subscription" 
            onPress={handleCancelSubscription}
            style={styles.cancelButton}
            disabled={processing}
          />
        </View>
      )}

      <View style={styles.plansContainer}>
        {subscriptionPlans.map(plan => (
          <SubscriptionCard
            key={plan.id}
            title={plan.name}
            price={`$${plan.price / 100}/month`}
            features={plan.features || [
              'Access to premium content',
              'Ad-free experience',
              'Priority support'
            ]}
            selected={selectedPlan === plan.id}
            onSelect={() => setSelectedPlan(plan.id)}
            onSubscribe={() => handleSubscribe(plan.id)}
            disabled={processing || (currentSubscription && currentSubscription.status === 'active')}
          />
        ))}

        {subscriptionPlans.length === 0 && (
          <View style={styles.noPlansContainer}>
            <Text style={styles.noPlansText}>No subscription plans available</Text>
          </View>
        )}
      </View>

      {processing && (
        <View style={styles.processingContainer}>
          <ActivityIndicator size="large" color="#6200ee" />
          <Text style={styles.processingText}>Processing your request...</Text>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#757575',
  },
  header: {
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#757575',
  },
  currentSubscription: {
    margin: 16,
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#6200ee',
  },
  currentTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  planName: {
    fontSize: 22,
    fontWeight: '600',
    marginBottom: 8,
  },
  statusText: {
    fontSize: 16,
    marginBottom: 4,
  },
  statusActive: {
    color: 'green',
    fontWeight: '500',
  },
  renewalText: {
    fontSize: 16,
    marginBottom: 16,
    color: '#757575',
  },
  cancelButton: {
    backgroundColor: '#f44336',
    marginTop: 8,
  },
  plansContainer: {
    padding: 16,
  },
  noPlansContainer: {
    padding: 20,
    alignItems: 'center',
  },
  noPlansText: {
    fontSize: 16,
    color: '#757575',
  },
  processingContainer: {
    padding: 20,
    alignItems: 'center',
  },
  processingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#757575',
  },
});

export default SubscriptionScreen;
