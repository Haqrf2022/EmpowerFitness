import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TextInput, ScrollView, Alert, ActivityIndicator, TouchableOpacity } from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import { useAuth } from '../context/AuthContext';
import Button from '../components/Button';
import { apiRequest } from '../services/api';

const MediaUploadScreen = () => {
  const { user } = useAuth();
  const [image, setImage] = useState(null);
  const [caption, setCaption] = useState('');
  const [uploading, setUploading] = useState(false);

  // Function to pick an image from the gallery
  const handleImagePick = async () => {
    const options = {
      mediaType: 'photo',
      includeBase64: false,
      maxHeight: 2000,
      maxWidth: 2000,
    };

    try {
      const result = await launchImageLibrary(options);
      
      if (result.didCancel) {
        console.log('User cancelled image picker');
      } else if (result.errorCode) {
        console.log('Image picker error: ', result.errorMessage);
        Alert.alert('Error', result.errorMessage);
      } else {
        const selectedAsset = result.assets?.[0];
        if (selectedAsset) {
          setImage(selectedAsset);
        }
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to pick image.');
    }
  };

  // Function to upload the image and create a post
  const handleUpload = async () => {
    if (!image) {
      Alert.alert('Error', 'Please select an image first.');
      return;
    }

    if (!user || !user.sub) {
      Alert.alert('Error', 'You must be logged in to upload media.');
      return;
    }

    try {
      setUploading(true);

      // Create form data for the image
      const formData = new FormData();
      formData.append('file', {
        uri: image.uri,
        name: image.fileName || 'upload.jpg',
        type: image.type,
      });
      formData.append('caption', caption);
      formData.append('userId', user.sub);

      // Upload to backend
      const response = await apiRequest('POST', '/api/upload', formData, null, true);

      if (response.success) {
        // Clear the form after successful upload
        setImage(null);
        setCaption('');
        Alert.alert('Success', 'Your content has been uploaded!');
      } else {
        throw new Error(response.message || 'Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      Alert.alert('Error', error.message || 'Failed to upload content. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Upload Content</Text>
        <Text style={styles.subtitle}>Share your photos with the community</Text>
      </View>

      <View style={styles.uploadContainer}>
        <TouchableOpacity style={styles.imagePicker} onPress={handleImagePick}>
          {image ? (
            <Image source={{ uri: image.uri }} style={styles.previewImage} />
          ) : (
            <View style={styles.placeholderContainer}>
              <Text style={styles.placeholderText}>Tap to select an image</Text>
            </View>
          )}
        </TouchableOpacity>

        <View style={styles.formContainer}>
          <TextInput
            style={styles.captionInput}
            placeholder="Write a caption..."
            value={caption}
            onChangeText={setCaption}
            multiline
            maxLength={500}
          />

          <Button
            title={uploading ? 'Uploading...' : 'Upload Content'}
            onPress={handleUpload}
            disabled={uploading || !image}
            style={styles.uploadButton}
          />

          {uploading && (
            <ActivityIndicator size="large" color="#6200ee" style={styles.loader} />
          )}
        </View>
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.infoTitle}>Tips for great uploads:</Text>
        <Text style={styles.infoItem}>• Use high-quality images</Text>
        <Text style={styles.infoItem}>• Add a descriptive caption</Text>
        <Text style={styles.infoItem}>• Respect community guidelines</Text>
        <Text style={styles.infoItem}>• Ensure you have rights to share the content</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#757575',
  },
  uploadContainer: {
    margin: 16,
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
  },
  imagePicker: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  previewImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  placeholderContainer: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  placeholderText: {
    fontSize: 16,
    color: '#757575',
  },
  formContainer: {
    width: '100%',
  },
  captionInput: {
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  uploadButton: {
    backgroundColor: '#6200ee',
  },
  loader: {
    marginTop: 20,
  },
  infoContainer: {
    margin: 16,
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  infoItem: {
    fontSize: 16,
    marginBottom: 8,
    color: '#424242',
  },
});

export default MediaUploadScreen;
