import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../services/supabase';
import Button from '../components/Button';
import { apiRequest } from '../services/api';

const ProfileScreen = () => {
  const { user, logout } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);

  // Fetch user profile data
  const fetchProfile = async () => {
    try {
      if (!user || !user.sub) return;

      setLoading(true);
      
      // Get profile from Supabase
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.sub)
        .single();
      
      if (error) {
        console.error('Error fetching profile:', error);
        // Create profile if it doesn't exist
        if (error.code === 'PGRST116') {
          await createProfile();
          return;
        }
        throw error;
      }
      
      setProfile(data);
      
      // Get subscription status from API
      const subscriptionData = await apiRequest('GET', `/api/subscription/status/${user.sub}`);
      setSubscriptionStatus(subscriptionData.status);
    } catch (error) {
      console.error('Profile error:', error);
      Alert.alert('Error', 'Failed to load profile information.');
    } finally {
      setLoading(false);
    }
  };

  // Create initial profile
  const createProfile = async () => {
    try {
      if (!user) return;
      
      const newProfile = {
        id: user.sub,
        full_name: user.name || '',
        email: user.email || '',
        avatar_url: user.picture || '',
        updated_at: new Date().toISOString(),
      };
      
      const { data, error } = await supabase
        .from('profiles')
        .insert([newProfile])
        .select();
      
      if (error) throw error;
      
      setProfile(data[0]);
    } catch (error) {
      console.error('Error creating profile:', error);
      Alert.alert('Error', 'Failed to create profile.');
    }
  };

  // Load profile data on component mount
  useEffect(() => {
    fetchProfile();
  }, [user]);

  // Handle logout
  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout error:', error);
      Alert.alert('Error', 'Failed to log out.');
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6200ee" />
        <Text style={styles.loadingText}>Loading profile...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image 
          source={{ uri: profile?.avatar_url || 'https://via.placeholder.com/150' }} 
          style={styles.avatar} 
        />
        <Text style={styles.name}>{profile?.full_name || user?.name || 'User'}</Text>
        <Text style={styles.email}>{profile?.email || user?.email || ''}</Text>
      </View>

      <View style={styles.infoContainer}>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Member Since:</Text>
          <Text style={styles.infoValue}>
            {profile?.created_at 
              ? new Date(profile.created_at).toLocaleDateString() 
              : new Date().toLocaleDateString()}
          </Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Subscription:</Text>
          <Text style={[
            styles.infoValue, 
            subscriptionStatus === 'active' ? styles.statusActive : styles.statusInactive
          ]}>
            {subscriptionStatus === 'active' ? 'Active' : 'Inactive'}
          </Text>
        </View>
      </View>

      <View style={styles.actionContainer}>
        <Button 
          title="Edit Profile" 
          onPress={() => Alert.alert('Info', 'Edit profile functionality will be implemented soon.')}
          style={styles.editButton}
        />
        
        <Button 
          title="Log Out" 
          onPress={handleLogout}
          style={styles.logoutButton}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#757575',
  },
  header: {
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  email: {
    fontSize: 16,
    color: '#757575',
  },
  infoContainer: {
    backgroundColor: '#fff',
    marginTop: 16,
    padding: 16,
    borderRadius: 8,
    marginHorizontal: 16,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  infoLabel: {
    fontSize: 16,
    color: '#757575',
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '500',
  },
  statusActive: {
    color: 'green',
  },
  statusInactive: {
    color: 'red',
  },
  actionContainer: {
    marginTop: 16,
    marginHorizontal: 16,
  },
  editButton: {
    marginBottom: 12,
  },
  logoutButton: {
    backgroundColor: '#f44336',
  },
});

export default ProfileScreen;
