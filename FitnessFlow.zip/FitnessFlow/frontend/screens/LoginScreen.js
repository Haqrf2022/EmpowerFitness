import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useAuth } from '../context/AuthContext';
import Button from '../components/Button';

const LoginScreen = () => {
  const { login, error } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    const result = await login();
    setLoading(false);

    if (!result.success && result.error) {
      Alert.alert('Login Failed', result.error);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Text style={styles.logoText}>My Mobile App</Text>
        <Text style={styles.tagline}>Connect. Share. Thrive.</Text>
      </View>

      <View style={styles.formContainer}>
        <Button 
          title={loading ? 'Logging in...' : 'Login with Auth0'} 
          onPress={handleLogin}
          disabled={loading}
          style={styles.loginButton}
        />
        
        {loading && (
          <ActivityIndicator size="large" color="#6200ee" style={styles.loader} />
        )}

        {error && (
          <Text style={styles.errorText}>{error}</Text>
        )}

        <View style={styles.termsContainer}>
          <Text style={styles.termsText}>
            By logging in, you agree to our{' '}
            <Text style={styles.link}>Terms of Service</Text> and{' '}
            <Text style={styles.link}>Privacy Policy</Text>
          </Text>
        </View>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          © 2023 My Mobile App. All rights reserved.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    justifyContent: 'space-between',
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: 100,
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#6200ee',
    marginBottom: 10,
  },
  tagline: {
    fontSize: 18,
    color: '#757575',
    textAlign: 'center',
  },
  formContainer: {
    padding: 20,
  },
  loginButton: {
    height: 50,
    marginVertical: 10,
  },
  loader: {
    marginVertical: 20,
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
    marginVertical: 10,
  },
  termsContainer: {
    marginTop: 20,
  },
  termsText: {
    fontSize: 12,
    color: '#757575',
    textAlign: 'center',
  },
  link: {
    color: '#6200ee',
  },
  footer: {
    padding: 20,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    color: '#757575',
  },
});

export default LoginScreen;
